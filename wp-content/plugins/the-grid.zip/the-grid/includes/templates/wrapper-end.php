<?php
/**
 * @package   The_Grid
 * @author    Themeone <themeone.master@gmail.com>
 * @copyright 2015 Themeone
 */

// Exit if accessed directly
if (!defined('ABSPATH')) { 
	exit;
}

	$wrapper_end = '</div>';
$wrapper_end .= '<!-- The Grid Wrapper End -->';

echo $wrapper_end;